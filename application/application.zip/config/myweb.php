<?php

$config['site_lang']	= "en";
$config['site_name']	= "Myweb";
$config['copyright_dev'] = '<strong>Myweb</strong> &copy; '.date("Y").'';