<?php 
class M_product extends M_myweb
{
	private $filter;
	private $order_by;
	//private $limit;
	//private $offset;
	private $page;
	//lay danh sach tat ca product
	public function __construct() {
		parent::__construct();
		//$this->table = 'member';
		if (!isset($this->filter )) 
		   $this->filter = array();
		   
		if(!isset($order_by)){
			$this->order_by=array();
		}
	}
	public function getProducts()
	{
		$this->db->select("	product.id,
							product.name,
							product.short_des,
							product.detail_des,
							product.category_id,
							product.producerId,
							product.img3,
							product.img2,
							product.img1,
							product.event_id,
							product.price,
							product.promotion_id,
							product.inStock,
							product.deleted,
							category.id as `category_id`,
							category.name as `category_name`,");
		$this->db->where('product.deleted',0);
		// $this->db->where('product.id',$id);
		if($this->filter)
		{
			$this->db->where($this->filter);
		}
		if($this->order_by)
		{
			foreach($this->order_by as $field => $order)
			{
				$this->db->order_by($field,$order);
			}
		}
		$this->db->from('product');
		$this->db->join('category','category.id = product.category_id');
		if(isset($this->filter['product.id']))
		{
			return $this->db->get()->row();
		}else{
			return $this->db->get()->result();
		}
	}
	public function setFilter($filter,$value)
	{
		$this->filter[$filter] = $value;
	}
	public function setOrderBy($field,$order="ASC")
	{
		$this->order_by[$field]=$order;
	}
	public function setPage($page)
	{
		$this->page = $page;
	}
}
?>