<?php 
class M_category extends CI_model
{
    private $page;
    private $limit;
    private $offset;
    public function __construct() {
		parent::__construct();
		//$this->table = 'member';
        if (!isset($this->page)) 
            $this->page = 1;
        if (!isset($this->limit)) 
            $this->limit = 8;
		
	}
	//lay danh sach tat ca product
	public function getProductList()
	{
        $arr= array();
        $this->db->where('active',1);
        $this->db->where('deleted',0);
        $query = $this->db->get('category');
        foreach($query->result() as $row)
		{   
            $row->product=$this->loadProduct($row->id);
            $arr[$row->id]=$row;
		}
		return $arr;
    }

    function loadProduct($id){
        $arr= array();
        $this->db->where('active',1);
        $this->db->where('deleted',0);
        $this->db->where('category_id',$id);
        $query = $this->db->get('product');

        foreach($query->result() as $row)
        {
            $arr[]=$row;
        }
        return $arr;
    }

    function loadProductPage($category_id=false){
        $arr= array();
        if($this->page<=1){
            $this->offset=0;
        }else{
            $this->offset = ($this->page-1) * $this->limit;
        }
        $this->db->where('active',1);
        $this->db->where('deleted',0);
        if($category_id)
        {
            $this->db->where('category_id',$category_id);
        }
        $query = $this->db->get('product',$this->limit,$this->offset);
        foreach($query->result() as $row)
        {
            $arr[]=$row;
        }
        return $arr;
        

    }
    public function setPage($page)
	{
		$this->page = $page;
    }
    public function setLimit($limit)
	{
		$this->limit = $limit;
    }
    public function getCategory(){
        $arr= array();
        $this->db->where('active',1);
        $this->db->where('deleted',0);
        $this->db->where('level',0);
        $query=$this->db->get('category');
        foreach($query->result() as $row)
        {
            $level1 = $this->getCategoryLevel($row->id,1);
            if(!empty($level1)){
                // $row->level1=$menulevel;
                $arr_temp = array();
                foreach($level1 as $row2)
                {
                    $level2 = $this->getCategoryLevel($row2->id,2);
                    if(!empty($level2)){
                        $row2->level2=$level2;
                        
                    }
                    $arr_temp[] = $row2;
                }
                $row->level1=$arr_temp;
                $arr[]=$row;
            }else{
                $arr[]=$row;
            }
            
        }
        return $arr;
    }
    public function getCategoryLevel($parent_id,$level){
        $arr= array();
        $this->db->where('active',1);
        $this->db->where('deleted',0);
        $this->db->where('level',$level);
        $this->db->where('parent',$parent_id);
        $query=$this->db->get('category');
        foreach($query->result() as $row)
        {
            $arr[]=$row;
        }
        if(!empty($arr)){
            return $arr;
        }
        return NULL;
    }
}
?>