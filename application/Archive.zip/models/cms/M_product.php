<?php 
class M_product extends CI_model
{
	//lay danh sach tat ca product
	public function get_current_page_records($limit, $start)
	{
		$arr=array();
		$this->db->where('p.deleted',0);
		$this->db->select('p.id,p.name as name,c.name as category, p.hot, p.active as lock');
		$this->db->from('product p');
		$this->db->join('category c', 'p.category_id = c.id');
		$this->db->order_by("p.id", "desc");
		$this->db->limit($limit, $start);
		$query = $this->db->get();
		foreach($query->result() as $row)
		{
			$arr[]=$row;
		}
		return $arr;
	}
	public function get_total() 
    {
        return $this->db->count_all("product");
    }
}
?>