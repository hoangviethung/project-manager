
    <section class="product-overview py-4">
        <div class="container">
            <div class="row text-secondary bread-crumb my-4">
                <div class="col-12">
                <a href="<?php echo site_url();?>" style="text-decoration:none;color: #6c757d !important;">Home</a> / <a href="<?php echo site_url();?>category" style="text-decoration:none;color: #6c757d !important;">Sản Phẩm</a> / <?php echo $product->category_name;?> /
                    <b class="text-active"><?php echo $product->name;?> </b>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 product-overview-images">
                    <div class="row">
                        <div class="col-3">
                            <div class="swiper-container gallery-thumbs">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <img class="img-fluid" src="assets/public/avatar/<?php echo $product->img1;?>" alt="">
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="img-fluid" src="assets/public/avatar/<?php echo $product->img2;?>" alt="">
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="img-fluid" src="assets/public/avatar/<?php echo $product->img3;?>" alt="">
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-9">
                            <div class="swiper-container gallery-top">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <img class="img-fluid" src="assets/public/avatar/<?php echo $product->img1;?>" alt="">
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="img-fluid" src="assets/public/avatar/<?php echo $product->img2;?>" alt="">
                                    </div>
                                    <div class="swiper-slide">
                                        <img class="img-fluid" src="assets/public/avatar/<?php echo $product->img3;?>" alt="">
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 product-overview-info mt-5">
                    <div class="product-overview-info-wrap text-center">
                        <a href="" class="product-brand mb-2">Hãng Sản Xuất</a>
                        <h1 class="product-name my-2"><?php echo $product->name;?></h1>
                        <p class="text-active m-1">
                            <b>Thông tin chung:</b>
                        </p>
                        <p class="product-overview-info-desc mt-1" id="perfect-scrollbar-product-info"><?php echo $product->short_des;?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="product-details mb-3">
        <div class="container">
            <ul class="nav nav-tabs text-center justify-content-center" id="myTab" role="tablist">
                <li class="nav-item mx-3">
                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#product-details-desc" role="tab" aria-controls="product-details-desc"
                        aria-selected="true">Mô Tả Chi Tiết</a>
                </li>
                <li class="nav-item mx-3">
                    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#product-details-brand-info" role="tab" aria-controls="product-details-brand-info"
                        aria-selected="false">Thông Tin Hãng Sản Xuất</a>
                </li>
                <li class="nav-item mx-3">
                    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#product-details-question" role="tab" aria-controls="product-details-question"
                        aria-selected="false">Hỏi Đáp</a>
                </li>
            </ul>
            <div class="tab-content text-center py-5" id="myTabContent">
                <div class="tab-pane fade show active" id="product-details-desc" role="tabpanel" aria-labelledby="product-details-desc-tab">
                <?php echo $product->detail_des;?>
                </div>

                <div class="tab-pane fade" id="product-details-brand-info" role="tabpanel" aria-labelledby="product-details-brand-info-tab">
                    Chưa có thông tin
                </div>

                <div class="tab-pane fade" id="product-details-question" role="tabpanel" aria-labelledby="product-details-question-tab">
                    <div class="row text-left">
                        <div class="col-md-6">
                            <h3 class="product-details-question-title">
                                Chưa có câu hỏi cho <?php echo $product->name;?>
                            </h3>

                            <!-- <div class="product-details-question-item">
                                <div class="product-details-customer">
                                    <div class="user-profile-picture-wrap">
                                        <img src="img/user.jpg" alt="" class="product-details-customer-profile-picture">
                                    </div>
                                    <div class="product-details-customer-question">
                                        <p class="product-details-customer-name">
                                            <strong>Khách hàng 1</strong> -
                                            <span class="question-date">21 tháng 3, 2018</span>
                                        </p>
                                        <p class="product-details-customer-question-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae iure magni alias consectetur
                                            earum sequi distinctio eius maiores minus cumque aperiam modi tempora explicabo
                                            voluptatum, non ea? Iusto, accusantium provident.</p>
                                    </div>
                                </div>
                                <div class="product-details-admin">
                                    <div class="user-profile-picture-wrap">
                                        <img src="img/admin.jpg" alt="" class="product-details-admin-profile-picture">
                                    </div>
                                    <div class="product-details-admin-answer">
                                        <p class="product-details-admin-name">
                                            <strong>Admin</strong> -
                                            <span class="answer-date">22 tháng 3, 2018</span>
                                        </p>
                                        <p class="product-details-admin-answer-text">Lorem ipsum dolor sit amet consectetur elit. Adipisci laborum temporibus maiores
                                            quis accusantium aliquam cum corrupti, iste omnis, tenetur minima natus corporis
                                            sunt earum reiciendis sapiente velit vitae quia.</p>
                                    </div>
                                </div>
                                <hr>
                            </div> -->
                        
                        </div>
                        <div class="col-md-6 product-details-question-input">
                            <h3 class="product-details-question-title text-left">
                                Thắc mắc về sản phẩm ? Hỏi ngay!
                                ( tính năng chưa sử dụng được, chúng tôi xin lỗi vì sự bất tiện này)
                            </h3>

                            <p class="required-field-desc">Email của bạn sẽ không được công khai. Những trường bắt buộc được đánh dấu *.</p>
                            <form action="">
                                <label for="question">Câu hỏi của bạn *</label>
                                <textarea name="question" id="question" cols="30" rows="5" class="form-control" required disabled></textarea>
                                <div class="row mt-2">
                                    <div class="col-6">
                                        <label for="customer-name">Tên *</label>
                                        <input type="text" name=customer-name id=customer-name class="form-control" required disabled>
                                    </div>
                                    <div class="col-6">
                                        <label for="customer-email">Email *</label>
                                        <input type="text" name=customer-email id=customer-email class="form-control" required disabled>
                                    </div>
                                </div>
                                <button type=submit class="btn question-submit-btn" disabled>Gửi Câu Hỏi</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>