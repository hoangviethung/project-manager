<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
        integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <?php
    switch($this->uri->rsegment(1))
    {
        case 'category':
        echo '<link rel="stylesheet" href="'.site_url("statics/default/css/category.css").'">';
        break;

        case 'about':
        echo '<link rel="stylesheet" href="'.site_url("statics/default/css/about.css").'">';
        break;

        case 'partner':
        echo '<link rel="stylesheet" href="'.site_url("statics/default/css/partner.css").'">';
        break;

        case 'product':
        echo '<link rel="stylesheet" href="'.site_url("statics/default/css/product.css").'">';
        break;

        case 'gallery':
        echo '<link rel="stylesheet" href="'.site_url("statics/default/css/gallery.css").'">
        <link rel="stylesheet" href="'.site_url("statics/default/fancybox-master/dist/jquery.fancybox.min.css").'">';
        break;

        case 'news':
        echo '<link rel="stylesheet" href="'.site_url("statics/default/css/news.css").'">
        <link rel="stylesheet" href="'.site_url("statics/default/css/news_detail.css").'">';
        break;

        default:
        echo '<link rel="stylesheet" href="statics/default/css/index.css">';
    }
    ?>
    <link rel="stylesheet" href="<?php echo site_url('statics/default/css/header.css');?>">





    <link rel="stylesheet" href="statics/default/swiper/dist/css/swiper.min.css">
    <link rel="stylesheet" href="statics/default/perfect-scrollbar/css/perfect-scrollbar.css">
    <link rel="stylesheet" href="statics/default/owl/dist/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="statics/default/owl/dist/assets/owl.theme.default.min.css">
    <link
        href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=vietnamese"
        rel="stylesheet">
    <title><?php echo $title;?></title>
</head>

<body>
    <header>
        <nav class="navbar-expand-lg navbar-dark navbar-lg" id="navbartop">
            <div class="container navbar-desktop brand-bar">
                <a class="navbar-brand brand-md my-0 text-white text-center" href="<?php echo site_url();?>">
                    <p class="brand-logo">NguyenQuanCo</p>
                </a>

                <p class="brand-slogan navbar-brand brand-md mr-auto text-white text-center">Slogan</p>

                <form class="form-inline ml-auto my-lg-0">
                    <input class="form-control mr-sm-2 search-input" type="search" placeholder="Từ khoá tìm kiếm">
                    <!-- <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> -->
                    <button type="submit" class="search-submit-button">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
            </div>
            <div class="container menu-bar">
                <ul class="navbar-nav navbar-nav-lg">
                    <li class="nav-item <?php echo $this->uri->segment(1)==''? "active" : "";?>">
                        <a class="nav-link mx-2 text-white" href="<?php echo site_url();?>">Trang Chủ
                        </a>
                    </li>
                    <li class="nav-item <?php echo $this->uri->segment(1)=='category' || $this->uri->segment(1)=='product' ? "active" : "";?>">
                        <a class="nav-link mx-2 text-white" href="<?php echo site_url();?>category">Sản Phẩm</a>
                    </li>
                    <li class="nav-item <?php echo $this->uri->segment(1)=='gallery'? "active" : "";?>">
                        <a class="nav-link mx-2 text-white" href="<?php echo site_url();?>gallery">Hình Ảnh</a>
                    </li>
                    <li class="nav-item <?php echo $this->uri->segment(1)=='news'? "active" : "";?>">
                        <a class="nav-link mx-2 text-white" href="<?php echo site_url();?>news">Tin Tức</a>
                    </li>
                    <li class="nav-item <?php echo $this->uri->segment(1)=='about'? "active" : "";?>">
                        <a class="nav-link mx-2 text-white" href="<?php echo site_url();?>about">Về Chúng Tôi</a>
                    </li>
                    <li class="nav-item <?php echo $this->uri->segment(1)=='partner'? "active" : "";?>">
                        <a class="nav-link mx-2 text-white" href="<?php echo site_url();?>partner">Đối Tác</a>
                    </li>

                </ul>
            </div>
        </nav>
        <nav class="navbar navbar-expand-lg navbar-dark navbar-mobile">
            <div class="container">
                <a class="navbar-brand brand-sm text-white" href="#">NguyenQuanCo
                    <span class="text-white mr-auto ml-2 small">slogan</span>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                        <li class="nav-item <?php echo $this->uri->segment(1)==''? "active" : "";?>">
                            <a class="nav-link text-white" href="<?php echo site_url();?>">Trang Chủ
                            </a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1)=='category' || $this->uri->segment(1)=='product' ? "active" : "";?>">
                            <a class="nav-link text-white" href="<?php echo site_url();?>category">Sản Phẩm</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1)=='gallery'? "active" : "";?>">
                            <a class="nav-link text-white" href="<?php echo site_url();?>gallery">Hình Ảnh</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1)=='news'? "active" : "";?>">
                            <a class="nav-link text-white" href="<?php echo site_url();?>news">Tin Tức</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1)=='about'? "active" : "";?>">
                            <a class="nav-link text-white" href="<?php echo site_url();?>about">Về Chúng Tôi</a>
                        </li>
                        <li class="nav-item <?php echo $this->uri->segment(1)=='partner'? "active" : "";?>">
                            <a class="nav-link text-white" href="<?php echo site_url();?>partner">Đối Tác</a>
                        </li>

                    </ul>

                    <form class="form-inline my-2 my-lg-0">
                        <input class="form-control mr-sm-2 search-input" type="search" placeholder="Từ khoá tìm kiếm">
                        <button type="submit" class="search-submit-button">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
            </div>
        </nav>
    </header>   