 <!-- Footer -->
 <footer class="footer-distributed">
        <div class="container">


            <div class="footer-left">

                <h3>NguyenQuanCo's
                    <span>logo</span>
                </h3>

                <p class="footer-links">
                    <a href="#">Home</a>
                    ·
                    <a href="#">Products</a>
                    ·
                    <a href="#">About Us</a>
                    ·
                    <a href="#">Đối Tác</a>

                </p>

                <p class="footer-company-name">NguyenQuanCo &copy; 2018</p>
            </div>



            <div class="footer-center">
                <!-- Button trigger modal -->
                <ul>
                    <li>
                        <a href="">Đối tác miền Bắc</a>
                    </li>
                    <li>
                        <a href="">Đối tác miền Trung</a>
                    </li>
                    <li>
                        <a href="">Đối tác miền Nam</a>
                    </li>
                </ul>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Đăng ký làm đối tác</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="#" method="post">
                                    <input type="text" name="name" placeholder="Tên Người Đại Diện" />
                                    <input type="text" name="company" placeholder="Tên Công Ty" />
                                    <input type="email" name="email" placeholder="Email" />
                                    <hr>
                                    <button type="button" class="btn" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn">Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-right">
                <div>
                    <i class="fa fa-map-marker"></i>
                    <p>
                        <span>Quận Thủ Đức</span> TP HCM, Việt Nam</p>
                </div>
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+84 907 82 5486</p>
                </div>
                <div>
                    <a href="#">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <p>
                        <a href="mailto:support@company.com">Địa chỉ Facebook</a>
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <div class="side-btn">
        <a href="#head">
            <img src="<?php echo site_url('statics/default/img/facebook_icon.png');?>" id="fixedbutton">
        </a>
        <a href="" class="modal-btn" data-toggle="modal" data-target="#exampleModal">
            <div class="partner-register">
                <div class="partner-register-circle text-center">
                    <i class="fas fa-handshake"></i>

                </div>
                <div class="partner-register-desc">Đăng ký đối tác</div>
            </div>
        </a>
    </div>
    <button class="back-to-top-btn text-center" id="back-to-top-btn">
        <i class="fas fa-arrow-up"></i>
    </button>

    <script src="<?php echo site_url('statics/default/jquery/dist/jquery.js');?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
    <script src="<?php echo site_url('statics/default/owl/dist/owl.carousel.min.js');?>"></script>
    <script src="<?php echo site_url('statics/default/animejs/anime.min.js');?>"></script>
    <script src="<?php echo site_url('statics/default/fancybox-master/dist/jquery.fancybox.js');?>"></script>
    <script src="<?php echo site_url('statics/default/masonry/imagesloaded.pkgd.js');?>"></script>
    <script src="<?php echo site_url('statics/default/masonry/isotope.pkgd.js');?>"></script>
    <?php $this->load->view('default/_layout/scripts');?>
    <script>
    <?php if($this->uri->segment(1)=="category"):?>
        $('body').on('click',".load-more", function()
        {
            var category = <?php echo isset($_GET['cate'])?$_GET['cate']:0;?>;
            var page = $('.current-page').val();
            var stopped = $('.stopped').val();
            $element = $('.product-list-content');
            if (stopped == 1){
                return false;
            }
            page++;
            $.ajax(
            {
                method        : 'POST',
                dataType    : 'text',
                url         : '<?php echo site_url("/category/getpageajax");?>',
                data        : {page : page,
                                category : category},
                success     : function (result)
                {
                    if(result)
                    {
                        $('.current-page').val(page);
                        $element.append($(result).hide().fadeIn(500));
                    }else{
                        $('.stopped').val(1);
                        $element.append($('<div class=col-12><p class=text-center><b>không còn sản phẩm</b></p></div>').hide().fadeIn(500));
                        $('.load-more').fadeOut(500);
                    }
                
                }
            })
        });
    <?php endif;?>

    <?php if($this->uri->segment(1)=="gallery"):?>
    $(document).ready(function(){
    $('body').on('click',".gallery-see-more", function()
        {
            var category = <?php echo isset($_GET['gallery_cate'])?$_GET['gallery_cate']:0;?>;
            var page = $('.current-page').val();
            var stopped = $('.stopped').val();
            $element = $('.grid');
            if (stopped == 1){
                return false;
            }
            page++;
            $.ajax(
            {
                method        : 'POST',
                dataType    : 'text',
                url         : '<?php echo site_url("/gallery/getpageajax");?>',
                data        : {page : page,
                                category : category},
                success     : function (result)
                {
                    if(result)
                    {
                        $('.current-page').val(page);

                        $element.isotope( 'insert',$(result).hide().fadeIn(500));
                        $('.grid').imagesLoaded().progress(function () { 
                            $('.grid').isotope('layout');
                        });
                    }else{
                        $('.stopped').val(1);
                        $element.after($('<div class=col-12><p class=text-center><b>không còn hình ảnh</b></p></div>').hide().fadeIn(500));
                        $('.gallery-see-more').fadeOut(500);
                    }
                
                }
            });
        });
    });
    <?php endif;?>
    </script>
</body>

</html>