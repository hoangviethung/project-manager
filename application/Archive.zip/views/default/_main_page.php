<?php
$this->load->view('default/_layout/header');
$this->load->view($subview);
$this->load->view('default/_layout/footer');
?>