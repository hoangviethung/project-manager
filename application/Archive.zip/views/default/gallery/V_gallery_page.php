<!-- <div class="grid">
                <div class="grid-sizer"></div> -->
                <?php foreach($images as $image):?>
                <div class="grid-item">
                    <a href="assets/public/avatar/<?php echo $image?$image->img:" ";?>" data-fancybox="<?php echo $image->gallery_id;?>" data-caption="<?php echo $image?$image->description:" ";?>">
                        <img src="assets/public/avatar/<?php echo $image?$image->img:" ";?>">
                    </a>
                </div>
                <?php endforeach;?>
           <!-- </div>
           </div> -->