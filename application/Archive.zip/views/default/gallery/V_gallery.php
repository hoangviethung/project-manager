<section class="gallery-banner">

    <div class="gallery-banner-wrap text-center">

        <h1 class="gallery-banner-title text-white text-center">
            Hình Ảnh
        </h1>
    </div>

</section>
<section class="gallery-main mb-5">
    <input type="hidden" value="1" class="current-page">
    <input type="hidden" value="0" class="stopped">
    <?php foreach($gallery_datas as $gallery_data):?>
    <?php if($this->gallery_cate):?>
        <?php if($gallery_data->id == $this->gallery_cate):?>
        <div class="container text-center album-wrap my-5">
            <div class="row album-title-wrap">
                <div class="album-title-line"></div>
                <h2 class="text-center album-title m-auto px-3">
                    <?php echo $gallery_data?$gallery_data->name:"";?>
                </h2>
            </div>

            <div class="grid">
                <div class="grid-sizer"></div>
                <?php foreach($gallery_data->images as $image):?>
                <div class="grid-item">
                    <a href="assets/public/avatar/<?php echo $image?$image->img:" ";?>" data-fancybox="<?php echo $gallery_data?$gallery_data->id:"
                        ";?>" data-caption="<?php echo $image?$image->description:" ";?>">
                        <img src="assets/public/avatar/<?php echo $image?$image->img:" ";?>">
                    </a>
                </div>
                <?php endforeach;?>
            </div>

        </div>
        <div class="row justify-content-center">
                <div class="col-auto">
                    <a class="btn btn-lg btn-warning text-white m-1 mt-3 gallery-see-more">See More</a>
                </div>
            </div>
        <?php endif;?>
    <?php else:?>
        <div class="container text-center album-wrap my-5">
            <div class="row album-title-wrap">
                <div class="album-title-line"></div>
                <h2 class="text-center album-title m-auto px-3">
                    <?php echo $gallery_data?$gallery_data->name:"";?>
                </h2>
            </div>

            <div class="grid">
                <div class="grid-sizer"></div>
                <?php foreach($gallery_data->images as $image):?>
                <div class="grid-item">
                    <a href="assets/public/avatar/<?php echo $image?$image->img:" ";?>" data-fancybox="<?php echo $gallery_data?$gallery_data->id:"
                        ";?>" data-caption="<?php echo $image?$image->description:" ";?>">
                        <img src="assets/public/avatar/<?php echo $image?$image->img:" ";?>">
                    </a>
                </div>
                <?php endforeach;?>
            </div>
            <div class="row justify-content-end">
                <div class="col-auto">
                    <a href="<?php echo site_url("gallery?gallery_cate=").$gallery_data->id;?>" class="btn btn-lg btn-warning text-white m-1 mt-3">See More</a>
                </div>
            </div>
    <?php endif;?>
    <?php endforeach;?>
</section>
