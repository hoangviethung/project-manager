
    <section class="news-banner">

        <div class="news-banner-wrap text-center">

            <h1 class="news-banner-title text-white text-center">
               <?php echo isset($cate)?$cate->name:"Tin Tức";?>
            </h1>
        </div>

    </section>

    <section class="news-main my-5">
        <div class="container">
            <div class="row">
                <div class="col-md-3 text-center text-md-left">
                    <div class="news-categories">
                        <h2 class="news-categories-title">CATEGORIES</h2>
                        <ul class="news-categories-list">
                        <?php foreach($news_categories as $news_category):?>
                            <li class="news-categories-list-item <?php echo $news_category->id==$this->cate?"active":'';?>">
                                <a href="<?php echo site_url('news?cate=').$news_category->id;?>" class=text-muted><?php echo $news_category?$news_category->name:'';?></a>
                            </li>
                        <?php endforeach;?>
                        </ul>
                    </div>
                </div>
                <div class="col-md-9 news-item-list">
                <?php foreach($news_datas as $news_data):?>
                    <div class="row news-item mb-5">
                        <div class="col-md-6">
                            <div class="news-image">
                                <div class="news-date">
                                    <p><?php echo date('d',strtotime($news_data->created_at));?>
                                        <span><?php echo date('M',strtotime($news_data->created_at));?></span>
                                    </p>
                                </div>
                                <img src="<?php echo site_url('assets/public/avatar/').$news_data->img;?>" class="img-fluid" alt="">
                                <a href="<?php echo site_url('news/').$news_data->slug;?>" class=read-more>Read More</a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="news-overview text-center py-3">
                                <div class="news-overview-categories">
                                    <a href="<?php echo site_url('news?cate=').$news_data->category['id'];?>" class="news-overview-categories-item">
                                        <?php echo $news_data->category['name'];?>
                                    </a>
                                </div>
                                <h2 class="news-overview-title">
                                    <?php echo $news_data->name;?>
                                </h2>
                                <p class="news-overview-author">
                                    <small><?php echo $news_data->created_by;?></small>
                                </p>
                                <p class="news-overview-description"><?php echo $news_data->description;?></p>
                                <a href="<?php echo site_url('news/').$news_data->slug;?>" class="news-overview-read-more">READ MORE</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach;?>
                </div>
            </div>

            <nav aria-label="Page">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?php echo $this->page==1?"disabled":"";?>">
                        <a class="page-link text-dark" href="<?php echo site_url("news?page=").($current_page-1);echo $this->cate?"&cate=".$this->cate:"";?>" tabindex="-1">
                            Trước</a>
                    </li>
                    <?php if($current_page >1):?>
                    <li class="page-item">
                        <a class="page-link page text-dark" href="<?php echo site_url("news?page=").($current_page-1);echo $this->cate?"&cate=".$this->cate:"";?>"><?php echo $current_page - 1;?></a>
                    </li>
                    <?php endif;?>
                    <li class="page-item">
                        <a class="page-link page-active text-dark" href="<?php echo site_url("news?page=").$current_page;echo $this->cate?"&cate=".$this->cate:"";?>"><?php echo $current_page;?></a>
                    </li>
                    <?php if($current_page < $total_pages):?>
                    <li class="page-item">
                        <a class="page-link page text-dark" href="<?php echo site_url("news?page=").($current_page+1);echo $this->cate?"&cate=".$this->cate:"";?>"><?php echo $current_page + 1;?></a>
                    </li>
                    <?php endif;?>
                    <li class="page-item <?php echo $this->page>=$total_pages?"disabled":"";?>">
                        <a class="page-link text-dark" href="<?php echo site_url("news?page=").($current_page+1);echo $this->cate?"&cate=".$this->cate:"";?>">Sau</a>
                    </li>
                </ul>
            </nav>
        </div>
    </section>
