<section class="home-banner-slide">
    <div class="container-fluid">
        <div class="row">
            <div class="owl-carousel home-banner-slide-carousel">
            <?php if($banners):?>
                    <?php foreach($banners as $banner):?>
                    <div class="row justify-content-center banner-wrap">
                        <a href="<?php echo $banner?$banner->link:'';?>">
                        <img class="banner-image img-fluid" src="assets/public/avatar/<?php echo $banner?$banner->img:'';?>" alt="">
                        </a>
                        <div class="filter"></div>
                        
                    </div>
                <?php endforeach;?>
            <?php endif;?>
            </div>
        </div>
    </div>
</section>
<section class="home-category my-5">
    <div class="container my-2">
        <div class="row section-title-wrap">
            <div class="section-title-line"></div>
            <h2 class="text-center section-title m-auto px-3">DANH MỤC SẢN PHẨM</h2>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-6 category-item">
                <div class="figure category-figure-item">
                    <h3 class="category-item-title">Hoá Phẩm</h2>
                        <a href="category.html" class="home-category-item-link">
                            <img src="statics/default/img/banner_home-2.jpg" class="figure-img img-fluid rounded"
                                alt="">
                        </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 category-item">
                <div class="figure category-figure-item">
                    <h3 class="category-item-title">Mỹ Phẩm</h2>
                        <!-- <p class="category-item-total">42 Sản Phẩm</p> -->
                        <a href="category.html" class="home-category-item-link">
                            <img src="statics/default/img/category_product.png" class="figure-img img-fluid rounded"
                                alt="">
                        </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 category-item">
                <div class="figure category-figure-item">
                    <h3 class="category-item-title">Đồ Gia Dụng</h2>
                        <a href="category.html" class="home-category-item-link">
                            <img src="statics/default/img/category3.jpg" class="figure-img img-fluid rounded" alt="">
                        </a>
                </div>
            </div>
            <div class="col-lg-8 col-md-6 category-item">
                <div class="figure category-figure-item">
                    <h3 class="category-item-title">Thực Phẩm</h2>
                        <a href="category.html" class="home-category-item-link">
                            <img src="statics/default/img/banner2.png" class="figure-img img-fluid rounded" alt="">
                        </a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="home-partner my-5" style="margin:0px !important">
    <div class="container">
        <!-- <div class="row partner-background"> -->
        <div class="row">
            <div class="col-lg-12 col-md-12 offset-lg-12 offset-md-12" style="padding:0px;">
                <div class="partner-text-wrap text-white">
                    <!-- <h2 class=partner-title>Hệ Thống Phân Phối</h2> -->
                    <!-- <p class=partner-description>Sản phẩm chúng tôi đã có mặt ở toàn quốc với hệ thống đại lý:</p> -->
                    <div class="row hover01 column">
                        <div class="col-md-3 partner-item">
                            <figure>
                                <img src="statics/default/img/icon_1.png" />
                            </figure>
                            <!-- <img class="img_line"  src="statics/default/img/icon_1.png" class="img-fluid" /> -->
                            <p class="partner-text-place">3 Miền</p>
                        </div>
                        <div class="col-md-3 partner-item">
                            <figure>
                                <img src="statics/default/img/icon_2.png" />
                            </figure>
                            <!-- <img class="img_line"  src="statics/default/img/icon_1.png" class="img-fluid" /> -->
                            <p class="partner-text-place">10 Tỉnh Thành</p>
                        </div>
                        <div class="col-md-3 partner-item">
                            <figure>
                                <img src="statics/default/img/icon_3.png" />
                            </figure>
                            <!-- <img class="img_line"  src="statics/default/img/icon_1.png" class="img-fluid" /> -->
                            <p class="partner-text-place">120 Đại Lý</p>
                        </div>
                        <div class="col-md-3 partner-item">
                            <figure>
                                <img src="statics/default/img/icon_4.png" />
                            </figure>
                            <!-- <img class="img_line"  src="statics/default/img/icon_1.png" class="img-fluid" /> -->
                            <p class="partner-text-place">Hơn 3000 sản phẩm</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="home-feature" style="padding-top:40px">
    <div class="container">
        <div class="row section-title-wrap">
            <div class="section-title-line"></div>
            <h2 class="text-center section-title m-auto px-3"> SẢN PHẨM NỔI BẬT</h2>
        </div>
    </div>

    <p class="text-center section-description">Dòng mô tả</p>
    <div class="container text-center">
        <div class="row text-center" style="margin-top:10px">
            <?php foreach($products as $product):?>
            <div class="col-lg-3 col-sm-6" style="padding:5px">
                <div class="product_item">
                    <div class="hover01 hover15">

                        <figure class="product_img">
                            <img src="assets/public/avatar/<?php echo $product->img1 ?>" />
                        </figure>
                        <h6 class="product_name"><?php echo $product->name;?></h6>

                    </div>
                </div>
            </div>
            <?php endforeach;?>

        </div>
    </div>
</section>

<section class="home-feature bg-light" style="padding-top:40px">
    <div class="container">
        <div class="row section-title-wrap">
            <div class="section-title-line"></div>
            <h2 class="text-center section-title m-auto home-feature-title px-3">ĐIỂM NỔI BẬT CỦA SẢN PHẨM</h2>
        </div>
    </div>

    <p class="text-center section-description">Dòng mô tả</p>
    <div class="container">
        <div class="row">

            <div class="col-lg-5 feature-item-wrap">
                <div class="feature-item">
                    <h3 class="feature-item-title">Thân Thiện Với Môi Trường</h3>
                    <p class="feature-item-description">All the lorem ipsum generators on the Internet tend to
                        repeat predefined chunks as necessary.</p>
                </div>
                <div class="feature-item">
                    <h3 class="feature-item-title">Hiệu Quả Cao</h3>
                    <p class="feature-item-description">Consectetur, from a Lorem Ipsum passage, and going through
                        the cites of the word in classical.</p>
                </div>
                <div class="feature-item">
                    <h3 class="feature-item-title">Ít Độc Hại</h3>
                    <p class="feature-item-description">All the lorem ipsum generators on the Internet tend to
                        repeat predefined chunks as necessary.</p>
                </div>
            </div>

            <div class="col-lg-2 hover15 column" style="margin:0px;">
                <figure>
                    <img src="statics/default/img/product4.png" alt="feature" width=100% />
                </figure>
            </div>

            <div class="col-lg-5 feature-item-wrap text-right">
                <div class="feature-item">
                    <h3 class="feature-item-title">Thân Thiện Với Môi Trường</h3>
                    <p class="feature-item-description">All the lorem ipsum generators on the Internet tend to
                        repeat predefined chunks as necessary.</p>
                </div>
                <div class="feature-item">
                    <h3 class="feature-item-title">Hiệu Quả Cao</h3>
                    <p class="feature-item-description">Consectetur, from a Lorem Ipsum passage, and going through
                        the cites of the word in classical.</p>
                </div>
                <div class="feature-item">
                    <h3 class="feature-item-title">Ít Độc Hại</h3>
                    <p class="feature-item-description">All the lorem ipsum generators on the Internet tend to
                        repeat predefined chunks as necessary.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="home-featured-products py-5">
    <div class="container">
        <div class="row section-title-wrap">
            <div class="section-title-line"></div>
            <h2 class="text-center section-title m-auto px-3">SẢN PHẨM NỔI BẬT</h2>
        </div>
    </div>
    <div class="container">
        <div class="owl-carousel featured-products-slide">
            <?php foreach($products as $product):?>
            <div class="justify-content-center">
                <figure class="figure featured-products-item-figure bg-light">
                    <a href="<?php echo site_url('product?id='.$product->id);?>" class="featured-products-link">
                        <div class="featured-products-item-wrap">
                            <img class="featured-products-img img-fluid"
                                src="assets/public/avatar/<?php echo $product->img1 ?>" alt="">
                            <figcaption class="figure-caption m-auto">
                                <h3 class="featured-products-title text-center text-dark mt-2">
                                    <?php echo $product->name?></h3>
                            </figcaption>
                        </div>
                    </a>
                </figure>
            </div>
            <?php endforeach;?>
        </div>
    </div>
</section>