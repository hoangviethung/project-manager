<?php foreach($products as $item): ?>
<div class="col-md-3 category-product-item text-center my-3">
    <a href="<?php echo site_url('product?id='.$item->id);?>">
        <figure class=figure>
            <div class="category-product-item-img">
                <img src="assets/public/avatar/<?php echo $item->img1 ?>" alt="" class="img-fluid">
            </div>
            <figcaption>
                <h2 class="category-product-item-title"><?php echo $item->name?></h2>
                <p class="category-prodcut-item-desc"><?php echo $item->short_des?></p>
            </figcaption>
        </figure>
    </a>
</div>
<?php endforeach;?>