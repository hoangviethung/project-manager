<section class="category-banner">
    <div class="category-banner-wrap text-center">
        <div class="category-banner-wrap-layer"></div>
        <h1 class="category-title dropdown-btn text-white text-center mx-auto">
            Category
            <i class="product-back-icon fas fa-arrow-down ml-3"></i>
        </h1>
    </div>
</section>
<section class="category-product my-3">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="product-list">
                    <input type="hidden" value="1" class="current-page">
                    <input type="hidden" value="0" class="stopped">
                    <div>
                        <h1 class="category-banner-title text-white text-center">
                            <a href="category" class="text-white">
                                <i class="product-back-icon fas fa-arrow-left"></i>
                            </a><?php echo $this->cate?$cats[$this->cate]->name:'Tất cả sản phẩm' ?></h1>
                        <p style="text-align:center"><?php echo isset($cat)?$cat->description:"" ?></p>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-3">
                            <ul class="category-list level1">
                            <?php foreach($cates as $level0): ?>
                                <li class="category-list-item level1 <?php echo $this->cate==$level0->id?"active":'';?>">
                                    <h3 class="title level1-title"><a href="<?php echo site_url("category?cate=").$level0->id;?>"><?php echo $level0->name;?></a>
                                        <?php if(isset($level0->level1)): ?>
                                        <span class="title-icon"><i class="fas fa-chevron-down"></i></span>
                                        <?php endif;?>
                                    </h3>
                                        <ul class="category-list level2">
                                        <?php if(isset($level0->level1)): ?>
                                        <?php foreach($level0->level1 as $level1): ?>
                                            <li class="category-list-item level2 <?php echo $this->cate==$level1->id?"active":'';?>">
                                                <h3 class="title level2-title"><a href="<?php echo site_url("category?cate=").$level1->id;?>"><?php echo $level1->name;?></a>
                                                    <?php if(isset($level1->level2)): ?>
                                                    <span class="title-icon"><i class="fas fa-chevron-right"></i></span>
                                                    <?php endif;?>
                                                </h3>
                                                <ul class="category-list level3">
                                                    <?php if(isset($level1->level2)): ?>
                                                    <?php foreach($level1->level2 as $level2): ?>
                                                    <li class="category-list-item level3 <?php echo $this->cate==$level2->id?"active":'';?>">
                                                        <h3 class="title level3-title"><a href="<?php echo site_url("category?cate=").$level2->id;?>"><?php echo $level2->name;?></a>
                                                        </h3>
                                                    </li>
                                                    <?php endforeach;?>
                                                    <?php endif;?>
                                                </ul>
                                            </li>
                                        <?php endforeach;?>
                                        </ul>
                                    <?php endif;?>

                                </li>
                            <?php endforeach;?>
                            </ul>
                        </div>
                        <div class="col-md-9">
                        <div class="row text-secondary bread-crumb">
                            <div class="col-md-12 mb-3 text-right">
                                <a href="<?php echo site_url('category');?>" class=text-secondary>Home</a> 
                                <?php if($this->cate):?>
                                    <?php foreach($cates as $level0): ?>
                                        <?php if($this->cate==$level0->id):?>
                                        / <b class="text-active"><a href="<?php echo site_url('category?cate=').$level0->id;?>" class=text-secondary><?php echo $level0->name;?></a></b>
                                        <?php elseif(isset($level0->level1)): ?>
                                            <?php foreach($level0->level1 as $level1):?>
                                                <?php if($this->cate==$level1->id):?>
                                                / <a href="<?php echo site_url('category?cate=').$level0->id;?>" class=text-secondary><?php echo $level0->name;?></a> / <b class="text-active"><a href="<?php echo site_url('category?cate=').$level1->id;?>" class=text-secondary><?php echo $level1->name;?></a></b> 
                                                <?php elseif(isset($level1->level2)): ?> 
                                                    <?php foreach($level1->level2 as $level2):?>
                                                    / <a href="<?php echo site_url('category?cate=').$level0->id;?>" class=text-secondary><?php echo $level0->name;?></a> / <a href="<?php echo site_url('category?cate=').$level1->id;?>" class=text-secondary><?php echo $level1->name;?></a> / <b class="text-active"><a href="<?php echo site_url('category?cate=').$level2->id;?>" class=text-secondary><?php echo $level2->name;?></a></b>
                                                    <?php endforeach;?>
                                                <?php endif;?>
                                            <?php endforeach;?>
                                        <?php endif;?>
                                    <?php endforeach;?>
                                <?php endif;?>
                            </div>
                        </div>
                            <div class="row product-list-content">
                                <?php if($products):?>
                                <?php foreach($products as $item): ?>
                                <div class="col-md-3 col-sm-4 category-product-item text-center my-3">
                                    <a href="<?php echo site_url('product?id='.$item->id);?>"
                                        class="text-dark product-wrap-link">
                                        <figure class="figure">
                                            <div class="category-product-item-img">
                                                <img src="assets/public/avatar/<?php echo $item->img1 ?>" alt=""
                                                    class="img-fluid">
                                            </div>
                                            <figcaption class=p-2>
                                                <h2 class="category-product-item-title"><?php echo $item->name?></h2>
                                                <p class="category-prodcut-item-desc"><?php echo $item->short_des?></p>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                <p class="mx-auto mb-5"><b>Không có sản phẩm</b>
                                    <p>
                                        <?php endif;?>
                            </div>
                        </div>

                    </div>
                    <?php if($products):?>
                    <div class="col-12 btn load-more text-center">
                        <p>Load More</p>
                    </div>
                <?php endif;?>
                </div>


            </div>


        </div>
        <!-- <nav aria-label="Page">
                <ul class="pagination justify-content-center">
                    <li class="page-item disabled">
                        <a class="page-link text-dark" href="#" tabindex="-1">
                            Trước</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link page-active text-dark" href="#">1</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link page text-dark" href="#">2</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link page text-dark" href="#">3</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link text-dark" href="#">Sau</a>
                    </li>
                </ul>
            </nav> -->
    </div>
</section>