<?php
$this->load->view('cms/_layout/header');
$this->load->view($subview);
$this->load->view('cms/_layout/footer');
?>