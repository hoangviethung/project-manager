<!-- begin .app-main -->
<div class="app-main">

	<!-- begin .main-content -->
	<div class="main-content bg-clouds">

		<!-- begin .container-fluid -->
		<div class="container-fluid p-t-15">
			<div class="box b-a">
				<div class="box-body">
					<div style="min-height:1000px">
						<iframe width="100%" height="1000px" frameborder="0" style="background-color:#fff" src="<?php echo base_url('filemanager/dialog.php');?>" ></iframe>
					</div>
				</div>
			</div>

		</div>
		<!-- END: .container-fluid -->

	</div>
	<!-- END: .main-content -->
	
</div>
<!-- END: .app-main -->