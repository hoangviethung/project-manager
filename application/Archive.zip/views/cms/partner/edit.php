<?php
if(isset($id)){
	$action = site_url('admin/partner?act=upd&id='.$id.'&token='.$infoLog->token);
}else{
	$action = site_url('admin/partner?act=new&token='.$infoLog->token);
}
?>
<!-- begin .app-main -->
<div class="app-main">

	<!-- begin .main-heading -->
	<header class="main-heading shadow-2dp">
		<!-- begin dashhead -->
		<div class="dashhead bg-white">
			<div class="dashhead-titles">
				<h6 class="dashhead-subtitle">
					Nguyên Quân / Nhà phân phối
				</h6>
				<h3 class="dashhead-title">Quản lý nhà phân phối</h3>
			</div>

			<div class="dashhead-toolbar">
				<div class="dashhead-toolbar-item">
					Nhà phân phối / Quản lý nhà phân phối
				</div>
			</div>
		</div>
		<!-- END: dashhead -->
	</header>
	<!-- END: .main-heading -->

	<!-- begin .main-content -->
	<div class="main-content bg-clouds">

		<!-- begin .container-fluid -->
		<div class="container-fluid p-t-15">
			<div class="box b-a">
				<div class="box-body">
					<?php if(isset($_SESSION['system_msg'])){ echo $_SESSION['system_msg'];unset($_SESSION['system_msg']); }?>
					<div class="row">
						<?php echo form_open_multipart($action,array('autocomplete'=>"off",'id'=>"userform"));?>
							<div class="col-md-6">
								<div class="form-group required">
									<label class="control-label">Tên của hàng</label>
									<input type="text" class="form-control" name="Partner[name]" id="name" required value="<?php if(isset($obj->name)) echo $obj->name;?>"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group required">
									<label class="control-label">Slug</label>
									<input type="text" class="form-control" name="Partner[slug]" id="slug" required value="<?php if(isset($obj->slug)) echo $obj->slug;?>"/>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group required">
									<label class="control-label">Miền</label>
									<select name="Partner[area]">
										<option value="0" <?php if(isset($obj->area) && $obj->area == 0)  echo "selected";?>>Miền Nam</option>
										<option value="1" <?php if(isset($obj->area) && $obj->area == 1)  echo "selected";?>>Miền Trung</option>
										<option value="2" <?php if(isset($obj->area) && $obj->area == 2)  echo "selected";?>>Miền Bắc</option>
									</select>								
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group required">
									<label class="control-label">Địa chỉ</label>
									<input id="content" class="form-control" name="Partner[address]" required id="address" value="<?php if(isset($obj->address)) echo $obj->address;?>"/>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group required">
									<label class="control-label">Điện thoại</label>
									<input id="content" class="form-control" name="Partner[phone]" required id="phone" value="<?php if(isset($obj->phone)) echo $obj->phone;?>"/>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group required">
									<label class="control-label">Vĩ độ</label>
									<input id="content" class="form-control" name="Partner[latitude]" required id="lat" value="<?php if(isset($obj->	latitude)) echo $obj->latitude;?>"/>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group required">
									<label class="control-label">Kinh độ</label>
									<input id="content" class="form-control" name="Partner[longitude]" required id="long" value="<?php if(isset($obj->longitude)) echo $obj->longitude;?>"/>
								</div>
							</div>
							
							<div class="clearfix"></div>
							<div class="col-md-3">
								<a class="btn btn-default" href="<?php echo site_url('admin/user');?>">Back</a>
								<button type="reset" class="btn btn-warning">Reset</button>
								<button type="submit" id="formSubmit" class="btn btn-primary">Submit</button>
							</div>
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>

		</div>
		<!-- END: .container-fluid -->

	</div>
	<!-- END: .main-content -->

	
</div>
<!-- END: .app-main -->