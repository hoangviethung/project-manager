<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('default/m_product');
	}
	public function index()
	{
		$this->data['banners'] = $this->M_myweb->set_table('home_banner')->sets(array('deleted'=>0,'active'=>1))->gets();
		$this->m_product->setFilter("product.featured",1);
		$this->data['products'] = $this->m_product->getProducts();
		$this->data['title']	= "Trang Chủ";
		$this->data['subview'] 	= 'default/index/V_index';
		$this->load->view('default/_main_page',$this->data);
	}
}
