<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_controller {

	public function __construct(){
		parent::__construct();
		$this->id = $this->input->get('id');
		$this->load->model('default/m_product');
	}
	
	public function index()
	{
		$this->m_product->setFilter("product.id",$this->id);
		$this->data['product'] = $this->m_product->getProducts();
		$this->data['title']	= "Sản Phẩm";
		$this->data['subview'] 	= 'default/product/V_productDetail';
		$this->load->view('default/_main_page',$this->data);
	}
}