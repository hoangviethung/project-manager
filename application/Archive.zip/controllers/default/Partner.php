<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Partner extends CI_controller {

	public function __construct(){
		parent::__construct();
		$this->Model = $this->M_myweb->set_table('partner');
	}
	
	public function index()
	{
		// $myfile = fopen("partnerinfo/partner.txt", "r") or die("Unable to open file!");
		// $partner_info = fread($myfile,filesize("partnerinfo/partner.txt"));
		// fclose($myfile);
		// $partner = json_decode($partner_info);
		$partner = $this->Model->set('deleted',0)->set_orderby('name')->gets();
		$this->data['partner_nam'] = array();
		$this->data['partner_trung'] = array();
		$this->data['partner_bac'] = array();
		foreach($partner as $item){
			if($item->area == 0)
				$this->data['partner_nam'][]=$item;
			else if($item->area == 1)
				$this->data['partner_trung'][]=$item;
			else
				$this->data['partner_bac'][]=$item;
		}
		$this->data['title']	= "Hệ Thống";
		$this->data['subview'] 	= 'default/partner/V_partner';
		//print_r($this->data['partner_nam']);
		$this->load->view('default/_main_page',$this->data);
	}
}