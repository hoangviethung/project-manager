<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->Model = $this->M_myweb->set_table('about');
	}
	
	public function index()
	{
		//general
		$introduce_info = $this->Model->get();
		$this->data['introduce_info'] = $introduce_info;
		//history
		$this->Model = $this->M_myweb->set_table('history');
		$this->data['history'] 	= $this->Model->set_orderby('title')->gets();
		$this->data['title']	= "Về Chúng Tôi";
		$this->data['subview'] 	= 'default/about/V_about';
		//print_r($this->data['history']);
		$this->load->view('default/_main_page',$this->data);
	}
}