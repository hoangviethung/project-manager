<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->cate=isset($_GET['cate'])?$this->input->get('cate'):false;
		// $this->data['cates'] = $this->M_myweb->set_table('category')->gets();
		$this->load->model('default/m_category');
	}
	
	public function index()
	{
		$this->data['cates'] = $this->m_category->getCategory();
		$this->data['cats'] = $this->m_category->getProductList();
		if($this->cate)
		{
			$this->data['products']=$this->m_category->loadProductPage($this->cate);
		}else{
			$this->data['products']=$this->m_category->loadProductPage();
		}
		$this->data['title']	= "Sản Phẩm";
		$this->data['subview'] 	= 'default/category/V_category';
		$this->load->view('default/_main_page',$this->data);

	}
	public function getPageAjax()
	{
		$page = $_POST['page'];
		if(isset($page))
		{
			$category = $_POST['category']!=0?$_POST['category']:false;
			$this->m_category->setPage($page);
			$this->data['products'] = $this->m_category->loadProductPage($category);
			if($this->data['products'])
			{
				$this->load->view('default/category/V_product_page',$this->data);
			}
		}else{
			redirect(site_url('/category'));
		}
	}
}