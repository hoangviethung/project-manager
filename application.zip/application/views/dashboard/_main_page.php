<?php
$this->load->view('dashboard/_layout/header');
$this->load->view($subview);
$this->load->view('dashboard/_layout/footer');
?>